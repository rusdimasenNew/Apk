plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.autoclearcache30"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.autoclearcache30"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
