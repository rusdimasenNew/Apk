package id.autoclearcache30

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.pm.PackageManager
import java.io.DataOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private val checks = linkedMapOf<String, CheckBox>()
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 22, 32))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        }
        root.addView(label("AUTO CLEAR CACHE + GAME MODE", 22f))
        root.addView(label("Cache dibersihkan tiap 30 detik. Saat Roblox (com.roblox.client) terbuka di depan, pembersihan dijeda untuk mengurangi risiko stutter. Root/Magisk diperlukan.", 14f))
        status = label("Status: belum berjalan", 14f)
        root.addView(status)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = Button(this).apply { text = "Simpan pilihan" }
        val start = Button(this).apply { text = "Mulai" }
        val stop = Button(this).apply { text = "Hentikan" }
        buttons.addView(save, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(start, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        loadApps()
        save.setOnClickListener { saveSelection() }
        start.setOnClickListener { saveSelection(); startRootLoop() }
        stop.setOnClickListener { stopRootLoop() }
    }

    private fun loadApps() {
        val saved = prefs.getStringSet("packages", emptySet()) ?: emptySet()
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        for (app in apps) {
            val pkg = app.packageName
            val cb = CheckBox(this).apply {
                text = "${pm.getApplicationLabel(app)}\n$pkg"
                textSize = 14f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(90, 190, 255))
                isChecked = saved.contains(pkg)
                setPadding(0, 4, 0, 4)
            }
            checks[pkg] = cb
            list.addView(cb)
        }
    }

    private fun selectedPackages() = checks.filterValues { it.isChecked }.keys.toSet()

    private fun saveSelection(): Boolean {
        val selected = selectedPackages()
        if (selected.size < 3) {
            status.text = "Pilih minimal 3 aplikasi sebelum menyimpan."
            return false
        }
        prefs.edit().putStringSet("packages", selected).apply()
        status.text = "Tersimpan: ${selected.size} aplikasi."
        return true
    }

    private fun runSu(command: String): Pair<Int, String> {
        return try {
            val p = Runtime.getRuntime().exec("su")
            DataOutputStream(p.outputStream).use { it.writeBytes(command + "\nexit\n"); it.flush() }
            val output = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            code to output
        } catch (e: Exception) { -1 to (e.message ?: "Gagal menjalankan su") }
    }

    private fun startRootLoop() {
        if (selectedPackages().size < 3) {
            status.text = "Pilih minimal 3 aplikasi."
            return
        }
        val packages = selectedPackages().joinToString(" ")
        // A root-owned background loop continues after the Activity closes. It only empties cache folders,
        // not app data, media, login information, or databases.
        val script = """
            while true; do
              top="${'$'}(dumpsys activity activities 2>/dev/null | grep -m1 -E 'mResumedActivity|topResumedActivity')"
              case "${'$'}top" in
                *com.roblox.client*) sleep 5; continue ;;
              esac
              for p in $packages; do
                case "${'$'}p" in *[!A-Za-z0-9._]*|'') continue ;; esac
                for d in "/data/user/0/${'$'}p/cache" "/data/data/${'$'}p/cache"; do
                  if [ -d "${'$'}d" ]; then find "${'$'}d" -mindepth 1 -maxdepth 1 -exec rm -rf -- {} \; 2>/dev/null; fi
                done
              done
              sleep 30
            done
        """.trimIndent()
        executor.execute {
            val escaped = script.replace("'", "'\\''")
            val (code, output) = runSu("if [ -f /data/local/tmp/autoclearcache30.pid ]; then kill $(cat /data/local/tmp/autoclearcache30.pid) 2>/dev/null; fi; nohup sh -c '$escaped' >/dev/null 2>&1 & echo $! > /data/local/tmp/autoclearcache30.pid")
            runOnUiThread {
                status.text = if (code == 0) "Aktif. Cache dijeda saat Roblox di depan; izinkan akses root jika diminta." else "Root gagal: $output"
            }
        }
    }

    private fun stopRootLoop() {
        executor.execute {
            val (code, output) = runSu("if [ -f /data/local/tmp/autoclearcache30.pid ]; then kill $(cat /data/local/tmp/autoclearcache30.pid) 2>/dev/null; rm -f /data/local/tmp/autoclearcache30.pid; fi")
            runOnUiThread { status.text = if (code == 0) "Perintah hentikan dikirim." else "Tidak dapat menghentikan: $output" }
        }
    }
}
