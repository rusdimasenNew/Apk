# Auto Clear Cache 30s

Android Studio project (Kotlin) for rooted Android devices.

## Features
- Shows installed app packages and lets the user select packages.
- Requires at least 3 selected apps before saving/starting.
- Stores selected package names locally.
- Requests Magisk/root access and clears only each selected app's `cache` directory every 30 seconds.
- Game Mode: pauses all cache cleaning while Roblox (`com.roblox.client`) is detected as the foreground app, checking again every 5 seconds.

## Important limitations
- This is **source code**, not a compiled or signed APK.
- Root manager approval is required.
- Android vendor/OS changes may prevent access to some cache directories.
- Force-stopping or rebooting may affect the root loop; this initial version does not include a boot receiver or persistent service.
- The Stop button is a basic best-effort stop command and should be improved/tested on the target ROM before daily use.
- This does not clear app data, logins, databases, or user media.
- The Roblox pause is a best-effort foreground-app check and cannot guarantee that Roblox will never freeze. It avoids cache deletion while the game is foregrounded; it does not boost FPS directly.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build APK(s)**.
